void default_function_kernel(float* MirrorPadInput, float* data) {
  #pragma omp parallel for
  for (int32_t i0 = 0; i0 < 5; ++i0) {
    for (int32_t i1 = 0; i1 < 9; ++i1) {
      MirrorPadInput[((i0 * 9) + i1)] = data[((((3 <= i0) ? (4 - i0) : ((i0 < 1) ? (0 - i0) : (i0 - 1))) * 6) + ((i1 == 8) ? (13 - i1) : ((i1 < 2) ? (1 - i1) : (i1 - 2))))];
    }
  }
}

